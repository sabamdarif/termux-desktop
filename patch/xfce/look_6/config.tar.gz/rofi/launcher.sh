#!/usr/bin/env bash

## Author  : Aditya Shakya
## Mail    : adi1090x@gmail.com
## Github  : @adi1090x
## Twitter : @adi1090x

style_number="1"
theme="launchpad-${style_number}"
dir="$HOME/.config/rofi/"

rofi -no-lazy-grab -show drun -modi drun -theme $dir/"$theme"
