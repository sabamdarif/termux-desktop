#!/usr/bin/env bash
# ~/.config/polybar/scripts/weather.sh
# Automatically detects location via IP or uses manual city override
# Usage:
#   weather.sh                    # Auto-detect location
#   weather.sh [City]             # Override with specific city
#   weather.sh --short            # Short format (icon + temp only)
#   weather.sh [City] --short     # City with short format

# Cache files for better performance
CACHE_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/polybar"
LOCATION_CACHE="$CACHE_DIR/weather_location"
WEATHER_CACHE="$CACHE_DIR/weather_data"
CACHE_DURATION=1800  # 30 minutes

# Create cache directory if it doesn't exist
mkdir -p "$CACHE_DIR"

# Parse arguments
SHORT=false
MANUAL_CITY=""

for arg in "$@"; do
  if [[ "$arg" == "--short" ]]; then
    SHORT=true
  else
    MANUAL_CITY="$arg"
  fi
done

# Function to get location from IP
get_location() {
  # Check cache first (refresh every 24 hours)
  if [[ -f "$LOCATION_CACHE" ]]; then
    CACHE_AGE=$(($(date +%s) - $(stat -c %Y "$LOCATION_CACHE" 2>/dev/null || stat -f %m "$LOCATION_CACHE" 2>/dev/null)))
    if [[ $CACHE_AGE -lt 86400 ]]; then
      cat "$LOCATION_CACHE"
      return
    fi
  fi
  
  # Fetch location from IP (using ipapi.co as backup to wttr.in)
  LOCATION=$(curl -s --max-time 5 "https://ipapi.co/city" 2>/dev/null)
  
  # Fallback to wttr.in's IP detection
  if [[ -z "$LOCATION" || "$LOCATION" == "Undefined" ]]; then
    LOCATION=$(curl -s --max-time 5 "https://ipinfo.io/city" 2>/dev/null)
  fi
  
  # Final fallback
  if [[ -z "$LOCATION" || "$LOCATION" == "Undefined" ]]; then
    LOCATION="YOUR_CITY_NAME"
  fi
  
  # Cache the location
  echo "$LOCATION" > "$LOCATION_CACHE"
  echo "$LOCATION"
}

# Function to get weather data
get_weather() {
  local city="$1"
  
  # Check cache first
  if [[ -f "$WEATHER_CACHE" ]]; then
    CACHE_AGE=$(($(date +%s) - $(stat -c %Y "$WEATHER_CACHE" 2>/dev/null || stat -f %m "$WEATHER_CACHE" 2>/dev/null)))
    if [[ $CACHE_AGE -lt $CACHE_DURATION ]]; then
      cat "$WEATHER_CACHE"
      return
    fi
  fi
  
  # Fetch fresh weather data
  RAW=$(curl -s --max-time 10 "wttr.in/${city}?format=%C|%t|%l" 2>/dev/null || echo "N/A|N/A|N/A")
  
  # Cache the result
  echo "$RAW" > "$WEATHER_CACHE"
  echo "$RAW"
}

# Determine city to use
if [[ -n "$MANUAL_CITY" ]]; then
  CITY="$MANUAL_CITY"
else
  CITY=$(get_location)
fi

# Get weather data
RAW=$(get_weather "$CITY")

# Parse weather data
COND=$(echo "$RAW" | cut -d'|' -f1 | tr '[:upper:]' '[:lower:]' | xargs)
TEMP=$(echo "$RAW" | cut -d'|' -f2 | sed 's/+//;s/°C//;s/°F//' | xargs)
ACTUAL_LOCATION=$(echo "$RAW" | cut -d'|' -f3 | xargs)

# Use actual location from wttr.in if available
if [[ -n "$ACTUAL_LOCATION" && "$ACTUAL_LOCATION" != "N/A" ]]; then
  CITY=$(echo "$ACTUAL_LOCATION" | cut -d',' -f1)
fi

# Weather icon mapping (Nerd Font icons)
ICON=""

case "$COND" in
  *clear*|*sunny*)
    # Check if it's night time (rough estimation)
    HOUR=$(date +%H)
    if [[ $HOUR -ge 18 || $HOUR -le 6 ]]; then
      ICON=""  # moon
    else
      ICON="󰖙"  # sun
    fi
    ;;
  *partly*|*few*)
    HOUR=$(date +%H)
    if [[ $HOUR -ge 18 || $HOUR -le 6 ]]; then
      ICON=""  # partly cloudy night
    else
      ICON=""  # partly cloudy day
    fi
    ;;
  *overcast*)
    ICON=""  # overcast
    ;;
  *cloud*|*clouds*)
    ICON="󰅟"  # clouds
    ;;
  *rain*|*drizzle*|*shower*)
    ICON=""  # rain
    ;;
  *thunder*|*storm*)
    ICON=""  # thunderstorm
    ;;
  *snow*|*sleet*|*blizzard*)
    ICON=""  # snow
    ;;
  *mist*|*fog*|*haze*|*smoke*)
    ICON=""  # fog
    ;;
  *)
    ICON=""
    ;;
esac

# Fallbacks for missing data
[[ -z "$TEMP" || "$TEMP" == "N/A" ]] && TEMP="--"
[[ "$RAW" == "N/A|N/A|N/A" ]] && CITY="Offline"

# Format temperature
TEMP="${TEMP}°C"

# Output format
if $SHORT; then
  printf '%s %s\n' "$ICON" "$TEMP"
else
  printf '%s %s %s\n' "$ICON" "$CITY" "$TEMP"
fi
