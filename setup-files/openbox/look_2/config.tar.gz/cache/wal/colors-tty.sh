#!/bin/sh
[ "${TERM:-none}" = "linux" ] && \
    printf '%b' '\e]P0191a22
                 \e]P164667B
                 \e]P2745F99
                 \e]P35F6480
                 \e]P4686D88
                 \e]P59274C0
                 \e]P67C809C
                 \e]P7b7b9c6
                 \e]P880818a
                 \e]P964667B
                 \e]PA745F99
                 \e]PB5F6480
                 \e]PC686D88
                 \e]PD9274C0
                 \e]PE7C809C
                 \e]PFb7b9c6
                 \ec'
