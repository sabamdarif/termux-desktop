static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#b7b9c6", "#191a22" },
	[SchemeSel] = { "#b7b9c6", "#64667B" },
	[SchemeOut] = { "#b7b9c6", "#7C809C" },
};
