static const char norm_fg[] = "#b7b9c6";
static const char norm_bg[] = "#191a22";
static const char norm_border[] = "#80818a";

static const char sel_fg[] = "#b7b9c6";
static const char sel_bg[] = "#745F99";
static const char sel_border[] = "#b7b9c6";

static const char urg_fg[] = "#b7b9c6";
static const char urg_bg[] = "#64667B";
static const char urg_border[] = "#64667B";

static const char *colors[][3]      = {
    /*               fg           bg         border                         */
    [SchemeNorm] = { norm_fg,     norm_bg,   norm_border }, // unfocused wins
    [SchemeSel]  = { sel_fg,      sel_bg,    sel_border },  // the focused win
    [SchemeUrg] =  { urg_fg,      urg_bg,    urg_border },
};
