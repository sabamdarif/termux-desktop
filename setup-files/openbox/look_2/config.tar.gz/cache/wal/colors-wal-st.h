const char *colorname[] = {

  /* 8 normal colors */
  [0] = "#191a22", /* black   */
  [1] = "#64667B", /* red     */
  [2] = "#745F99", /* green   */
  [3] = "#5F6480", /* yellow  */
  [4] = "#686D88", /* blue    */
  [5] = "#9274C0", /* magenta */
  [6] = "#7C809C", /* cyan    */
  [7] = "#b7b9c6", /* white   */

  /* 8 bright colors */
  [8]  = "#80818a",  /* black   */
  [9]  = "#64667B",  /* red     */
  [10] = "#745F99", /* green   */
  [11] = "#5F6480", /* yellow  */
  [12] = "#686D88", /* blue    */
  [13] = "#9274C0", /* magenta */
  [14] = "#7C809C", /* cyan    */
  [15] = "#b7b9c6", /* white   */

  /* special colors */
  [256] = "#191a22", /* background */
  [257] = "#b7b9c6", /* foreground */
  [258] = "#b7b9c6",     /* cursor */
};

/* Default colors (colorname index)
 * foreground, background, cursor */
 unsigned int defaultbg = 0;
 unsigned int defaultfg = 257;
 unsigned int defaultcs = 258;
 unsigned int defaultrcs= 258;
