static const char* selbgcolor   = "#191a22";
static const char* selfgcolor   = "#b7b9c6";
static const char* normbgcolor  = "#745F99";
static const char* normfgcolor  = "#b7b9c6";
static const char* urgbgcolor   = "#64667B";
static const char* urgfgcolor   = "#b7b9c6";
