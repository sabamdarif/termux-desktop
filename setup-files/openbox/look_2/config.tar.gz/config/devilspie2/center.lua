if (get_window_type() == "NORMAL") then
    center()
end
