sleep 3 && picom --config '/data/data/com.termux/files/home/.config/picom/picom.conf'

