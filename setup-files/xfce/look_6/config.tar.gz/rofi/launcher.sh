#!/usr/bin/bash
	## Run
	rofi  -show drun -theme $HOME/.config/rofi/style.rasi
